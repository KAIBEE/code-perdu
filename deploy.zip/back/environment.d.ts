declare const process: {
  env: {
    API_PREFIX?: string;
    MAIL_USER: string;
    MAIL_PASSWORD: string;
    NODE_ENV: string;
  };
};
