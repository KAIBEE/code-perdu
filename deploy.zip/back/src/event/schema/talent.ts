export type Talent = 'FRONT' | 'BACK' | 'DEVOPS' | 'PRODUCT';
