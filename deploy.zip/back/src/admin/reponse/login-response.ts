export type LoginResponse = { success: boolean };
