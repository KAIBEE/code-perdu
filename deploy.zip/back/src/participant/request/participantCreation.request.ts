export class ParticipantCreationRequest {
  email: string;
}
