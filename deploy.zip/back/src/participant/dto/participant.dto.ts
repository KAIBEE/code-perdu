export class ParticipantDto {
  readonly email: string;
  readonly code: string;
  readonly isCompleted: boolean;
}
