export const baseUrl =
    process.env.NODE_ENV === "production" ? "/api" : "http://localhost:3000";

export const EVENT_ID = "651424209c61c018b28c5270";