import styled from "styled-components";

export const Header = styled.header`
  text-align: center;
  display: flex;
  justify-content: center;
`;
