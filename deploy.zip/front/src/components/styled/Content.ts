import styled from "styled-components";

export const Content = styled.div`
  color: #ffffff;
  margin: 2rem;
  font-family: Crimson Text;
  font-size: 1.5em;
  font-weight: 400;
  line-height: 32px;
`;
