import styled from 'styled-components';

export const SmallParagraph = styled.p`
color: #63BFBC;
font-style: italic;
`;