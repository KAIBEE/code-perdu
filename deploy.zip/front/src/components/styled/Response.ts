import styled from "styled-components";

export const Response = styled.div`
  width: 75%;
  text-align: center;
`;
